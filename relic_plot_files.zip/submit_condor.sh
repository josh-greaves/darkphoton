#!/bin/bash

arg=$2
exe=$1
#args=`echo "${@:3}"`

home=`pwd`

echo  "submitting jobs using "$exe" with arg:"$arg     # THIS will not work with multiple arguments unless one uses the commented out 'args' line above. 
echo "executable              = "$exe > tmp.sub
echo "arguments               = "$arg >> tmp.sub
echo "output                  = condor/output/welcome.\$(ClusterId).\$(ProcId).out" >> tmp.sub
echo "error                   = condor/error/welcome.\$(ClusterId).\$(ProcId).err"  >> tmp.sub
echo "log                     = condor/log/welcome.\$(ClusterId).\$(ProcId).log"                >> tmp.sub
echo "+JobFlavour = \"testmatch\"  " >> tmp.sub     # workday   # microcentury   # espresso  # longlunch  #tomorrow
#~ echo "+MaxRuntime = 3600" >> tmp.sub   # in seconds
echo "queue "    >> tmp.sub   # $N 
condor_submit tmp.sub

