#include "TStyle.h"
#include "TColor.h"
#include "TLegend.h"
#include "TStyle.h"

void set_plot_style() {
    const Int_t NRGBs = 5;
    const Int_t NCont = 255;

    Double_t stops[NRGBs] = { 0.00, 0.34, 0.61, 0.84, 1.00 };
    Double_t red[NRGBs]   = { 0.00, 0.00, 0.87, 1.00, 0.51 };
    Double_t green[NRGBs] = { 0.00, 0.81, 1.00, 0.20, 0.00 };
    Double_t blue[NRGBs]  = { 0.51, 1.00, 0.12, 0.00, 0.00 };
    //gStyle->CreateGradientColorTable(NRGBs, stops, red, green, blue, NCont);                                                                                                                                                                                                                                                                                                                                      
    TColor::CreateGradientColorTable(NRGBs, stops, red, green, blue, NCont);
    gStyle->SetNumberContours(NCont);
}
void Prep() {
  //gInterpreter->Load("MitWlnu/NYStyle/interface/NYGuns_hh.so");                                                                                                                                                                                                                                                                                                                                                   
  TStyle *GloStyle;
  GloStyle = gStyle; // Save the global style reference                                                                                                                                                                                                                                                                                                                                                             

  TStyle *NYStyle = new TStyle("New York Style","Fuck You Bitch");
  gStyle = NYStyle;

  // Paper size                                                                                                                                                                                                                                                                                                                                                                                                     

  NYStyle->SetPaperSize(gStyle->kUSLetter);
  NYStyle->SetPalette(1,0);
  // Canvas                                                                                                                                                                                                                                                                                                                                                                                                         

  NYStyle->SetCanvasColor     (  0);
  NYStyle->SetCanvasBorderSize( 10);
  NYStyle->SetCanvasBorderMode(  0);
  NYStyle->SetCanvasDefH      (600);
  NYStyle->SetCanvasDefW      (550);
  NYStyle->SetCanvasDefX      ( 10);
  NYStyle->SetCanvasDefY      ( 10);

  // Pads                                                                                                                                                                                                                                                                                                                                                                                                           

  NYStyle->SetPadColor       (    0);
  NYStyle->SetPadBorderSize  (   10);
  NYStyle->SetPadBorderMode  (    0);
  NYStyle->SetPadBottomMargin(0.100);
  NYStyle->SetPadTopMargin   (0.100);
  NYStyle->SetPadLeftMargin  ( 0.15);
  NYStyle->SetPadRightMargin ( 0.15);
  NYStyle->SetPadGridX       (    0);
  NYStyle->SetPadGridY       (    0);
  NYStyle->SetPadTickX       (    0);
  NYStyle->SetPadTickY       (    0);

  // Frames                                                                                                                                                                                                                                                                                                                                                                                                         

  NYStyle->SetFrameFillStyle ( 0);
  NYStyle->SetFrameFillColor ( 0);
  NYStyle->SetFrameLineColor ( 1);
  NYStyle->SetFrameLineStyle ( 0);
  NYStyle->SetFrameLineWidth ( 1);
  NYStyle->SetFrameBorderSize(10);
  NYStyle->SetFrameBorderMode( 0);

  // Histograms                                                                                                                                                                                                                                                                                                                                                                                                     

  //NYStyle->SetHistFillColor(0);                                                                                                                                                                                                                                                                                                                                                                                   
  //NYStyle->SetHistFillStyle(3004);                                                                                                                                                                                                                                                                                                                                                                                
  //NYStyle->SetHistLineColor(1);                                                                                                                                                                                                                                                                                                                                                                                   
  //NYStyle->SetHistLineStyle(0);                                                                                                                                                                                                                                                                                                                                                                                   
  //NYStyle->SetHistLineWidth(3);                                                                                                                                                                                                                                                                                                                                                                                   

  // Functions                                                                                                                                                                                                                                                                                                                                                                                                      

  NYStyle->SetFuncColor(1);
  NYStyle->SetFuncStyle(0);
  NYStyle->SetFuncWidth(1);

  // Various                                                                                                                                                                                                                                                                                                                                                                                                        
  NYStyle->SetTitleBorderSize(1);
  NYStyle->SetTickLength ( 0.015,"X");
  NYStyle->SetTitleSize  ( 0.050,"X");
  NYStyle->SetTitleOffset( 1.000,"X");
  NYStyle->SetLabelOffset( 0.005,"X");
  NYStyle->SetLabelSize  ( 0.050,"X");
  NYStyle->SetLabelFont  ( 42   ,"X");
  NYStyle->SetNdivisions (509   ,"X");
  NYStyle->SetTitleFont  ( 42   ,"X");

  NYStyle->SetTickLength ( 0.015,"Y");
  NYStyle->SetTitleSize  ( 0.050,"Y");
  NYStyle->SetTitleOffset( 1.400,"Y");
  NYStyle->SetLabelOffset( 0.005,"Y");
  NYStyle->SetLabelSize  ( 0.050,"Y");
  NYStyle->SetLabelFont  ( 42   ,"Y");
  NYStyle->SetTitleFont  ( 42   ,"Y");
NYStyle->SetTitleOffset( 1.00 ,"Z");
  NYStyle->SetTitleFont  ( 42   ,"Z");
  NYStyle->SetTitleSize  ( 0.050,"Z");

  NYStyle->SetOptTitle (0);
  NYStyle->SetStatColor(0);
  NYStyle->SetStatFont       (42);
  NYStyle->SetTitleFont      (42);
  NYStyle->SetTitleBorderSize( 0);
  NYStyle->SetTitleFillColor (10);

  // Options                                                                                                                                                                                                                                                                                                                                                                                                        

  NYStyle->SetOptFit (0);
  NYStyle->SetOptStat(0);
  NYStyle->SetStatBorderSize(1);
  set_plot_style();
  return;
}
