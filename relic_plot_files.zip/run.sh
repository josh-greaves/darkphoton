#!/bin/bash

# args: mxd = dark matter mass
# e.g. run.sh 100 runs one job with dm mass = 100 GeV


mXd=$1

tar xzvf relic.tgz 			# This contains MG5 directory, which contains DMsimp and HAHM versions of: launch.txt, generate.txt, root_parser.py, relic_compute.C

cd MG5_aMC_v2_9_4/

sed "s@xPLACEHOLDERx@$mXd@g"  launch.txt > launch_tmp.txt 

python bin/maddm.py generate.txt
python bin/maddm.py launch_tmp.txt

python root_parser.py --dm $mXd 
root -b -q relic_compute.C 

# Copy outputs from local condor machine to /eos/ directory
cp Output.root /eos/user/.../output_directory/DMS_${mXd}.root				# Root file without calculation (root_parser.py output)
cp Output_proc.root /eos/user/.../output_directory/DMS_${mXd}_proc.root			# Root file after calculation (relic_compute.c output)
cp DMS_1/output/scan_run_01.txt /eos/user/.../scans/output_directory/scan_run_01_${mXd}.txt # Output from MadDM scan
cp DMS_1/Cards/param_card.dat /eos/user/.../params/output_directory/param_card_${mXd}.dat	# Param card for MadDM


