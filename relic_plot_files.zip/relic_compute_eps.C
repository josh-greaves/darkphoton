#include <iostream>
#include <sstream>
#include "TFile.h"
#include "TCanvas.h"
#include "TH2F.h"
#include <math.h>
#include "TGraph.h"
#include "TTree.h"
#include <stdio.h>


bool blnFlipVals = false;

double* relicCoupling(TTree *iTree,float iMed,float iDM) { 
	std::cout << "iMed: " << iMed << " iDM: " << iDM  <<"\n";
	
  std::stringstream pSS; pSS << "med == " << iMed << " && dm == " << iDM << "  && om > 0 && om < 100 ";
  std::cout << "pSS.str().c_str(): " << pSS.str().c_str() << "\n"; 
  
  int n = iTree->Draw("om:eps",pSS.str().c_str(),"goff");

  std::cout << "n: " << n << "\n";
  
  int lSplit = 0; 
  int pSlopeSign = 0; 
  double lYMax = -100; 
  double lYMin = 100;
  double *lGQMin = new double[2]; 
  lGQMin[0] = -1;
  lGQMin[1] = -1;
  for(int i0 = 0; i0 < n; i0++) {
	  if(lYMax < iTree->GetV1()[i0]) {
		  lYMax =  iTree->GetV1()[i0];
	  }
  }
  for(int i0 = 0; i0 < n; i0++) {
	  if(lYMin > iTree->GetV1()[i0]) {
		  lYMin =  iTree->GetV1()[i0];
	  }
  }
  
  
  if(0.12 < lYMin || 0.12 > lYMax) {std::cout << "BREAK HERE " <<  "lYmin: " << lYMin << " lYMax: " << lYMax <<" n: " << n << "lGQMin" << lGQMin[0] <<"\n"; return lGQMin;}
  for(int i0 = 1; i0 < n; i0++) { 
    double pX0 = iTree->GetV1()[i0-1]; 
    double pY0 = iTree->GetV2()[i0-1]; 
    double pX1 = iTree->GetV1()[i0]; 
    double pY1 = iTree->GetV2()[i0]; 
    double pSlope = 0; 
  
    if(pX1 != pX0) pSlope = (pY1-pY0)/(pX1-pX0);
    if(pSlope !=0 && pSlopeSign == 0) pSlopeSign = pSlope/fabs(pSlope);
    if(pSlope/fabs(pSlope) != pSlopeSign) {lSplit = i0-1; break;}
  }
  std::cout << "Sign ==" << n << " --> " << pSlopeSign << " -- lSplit:  " << lSplit << std::endl;
  double *lX0 = new double[lSplit];
  double *lY0 = new double[lSplit];
  double *lX1 = new double[n-lSplit];
  double *lY1 = new double[n-lSplit];
  for(int i0 = 0; i0 < n; i0++) { 
    if(i0 > lSplit-1)  { 
		std::cout << "iSplit, right side: " << lSplit << std::endl;
      lX1[i0-lSplit] = iTree->GetV1()[i0];   
      lY1[i0-lSplit] = iTree->GetV2()[i0];
    } else { 
	std::cout << "iSplit, left side: " << lSplit << std::endl;
      lX0[i0] = iTree->GetV1()[i0];   
      lY0[i0] = iTree->GetV2()[i0];
    }
  }  
  
  TGraph *g0 = new TGraph(lSplit  ,lX0,lY0);
  TGraph *g1 = new TGraph(n-lSplit,lX1,lY1); g1->SetLineColor(kGreen+1);
  lGQMin[0] = g0->Eval(0.12);
  lGQMin[1] = g1->Eval(0.12);
  std::cout << "g0 eval 0.12: " << g0->Eval(0.12) << std::endl;
  std::cout << "g1 eval 0.12: " << g1->Eval(0.12) << std::endl;
  
  std::cout << "TESTING: " << "\n" << "lGQMin[1]: " << lGQMin[1]  << ", => log(eps): " << log10(lGQMin[1]) << "  lSplit: " << lSplit << "\n";
  return lGQMin;
}
void relic_compute_eps() { 

  TCanvas *lC0 = new TCanvas("c0","c0",800,600);
  TFile *lFile = new TFile("Output_EPS.root");
  TTree *lTree = (TTree*) lFile->FindObjectAny("relic");
  TFile *lOFile = new TFile("Output_EPS_proc.root","RECREATE");
  TTree *lOTree = new TTree("relic","relic");
  float lMDM    = 0; lOTree->Branch("dm" ,&lMDM,"lMDM/F"); 
  float lMed    = 0; lOTree->Branch("med",&lMed,"lMed/F"); 
  float lGQ1    = 0; lOTree->Branch("gq1",&lGQ1,"lGQ1/F"); 
  float lGQ2    = 0; lOTree->Branch("gq2",&lGQ2,"lGQ2/F"); 
  
  //TH2F  *lH2D   = new TH2F("A","A",21,-0.5,20.5,2001,-0.5,2000.5);
  TH2F  *lH2D   = new TH2F("A","A",2001,-0.5,2000.5,2001,-0.5,2000.5);  
  //TH2F  *lH2D   = new TH2F("A","A",80,0,50,200,0,50);              // 80 bins from 0->50, 200 bins from 0 -> 50
  
  lTree->Draw("dm:med>>A","om > 0 && om < 100 && abs(log(om)-log(0.12)) < 3");
  
   for(int i0 = 0; i0 < lH2D->GetNbinsX()+1; i0++) {  
    for(int i1 = 0; i1 < lH2D->GetNbinsY()+1; i1++) { 
		blnFlipVals=false;
      if(lH2D->GetBinContent(i0,i1) == 0) continue;
	  std:cout << "i: " << i0 <<" " << i1<< "\n"  << "bincont:"<<lH2D->GetBinContent(i0,i1) << "\n" ;
      double pMed = lH2D->GetXaxis()->GetBinCenter(i0); 
      double pDM  = lH2D->GetYaxis()->GetBinCenter(i1); 
      double *lG = relicCoupling(lTree,pMed,pDM);
      std::cout << "pmed: " << pMed << " pDM: " << pDM << "\n" ;
      lMDM      = pDM;
      lMed      = pMed;
      
      if(lG[0] < lG[1] && lG[0]  != 0 && lG[0]  != -1 ) blnFlipVals=true;      // Flip values if gq2 has exploded. 
      std::cout << "==> " << pMed << " --> " << pDM << " -- " << lG[0] << " -- " << lG[1] << "\n" << "flip?: " << blnFlipVals << "\n \n " << std::endl;
      
      if(!blnFlipVals){
		  lGQ1      = lG[0];
		  lGQ2      = lG[1];
	  } else {
		  lGQ2      = lG[0];
		  lGQ1      = lG[1];
	  }
      
      lOTree->Fill();
    }
   }
  lOFile->cd();
  lOTree->Write();
  lOFile->Close();
}
