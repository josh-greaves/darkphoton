#! /usr/bin/env python
import os,sys

outdir="eps_200_200_7"

os.system("rm -r relic/%s/"%(str(outdir)))
os.system("mkdir relic/%s/"%(str(outdir)))
os.system("rm -r relic/scans/%s/"%(str(outdir)))
os.system("mkdir relic/scans/%s/"%(str(outdir)))
os.system("rm -r relic/params/%s/"%(str(outdir)))
os.system("mkdir relic/params/%s/"%(str(outdir)))

    
#####      SET mXd here       ######
MXd_array=[]
for i in range(1,201,1):
    MXd_array.append(i)
        
    
# Submit one job to condor for each Dark Matter mass mXd.
for MXd in MXd_array:
	# ~ cmd ="./submit_condor.sh run.sh %s"%(str(MXd))		# run.sh is for coupling sweep for DMsimp
	cmd ="./submit_condor.sh run_eps_tmp.sh %s "%(str(MXd))	# run_eps.sh is for epsilon sweep for HAHM
	os.system(cmd)
	#print(cmd)
