#!/bin/bash

# args: mxd = dark matter mass
# e.g. run_eps.sh 100 runs one job with dm mass = 100 GeV


mXd=$1

tar xzvf relic.tgz 			# This contains MG5 directory, which contains DMsimp and HAHM versions of: launch.txt, generate.txt, root_parser.py, relic_compute.C

cd MG5_aMC_v2_9_4/
sed "s@xPLACEHOLDERx@$mXd@g"  launch_eps.txt > launch_tmp.txt

python bin/maddm.py generate_eps.txt
python bin/maddm.py launch_tmp.txt

python root_parser_EPS.py --dm $mXd 
root -b -q relic_compute_eps.C 

# Copy outputs from local condor machine to /eos/ directory
cp Output_EPS.root /eos/user/.../output_directory/EPS_${mXd}.root				# Root file without calculation (root_parser.py output)
cp Output_EPS_proc.root /eos/user/.../output_directory/EPS_${mXd}_proc.root			# Root file after calculation (relic_compute.c output)
cp EPS_1/output/scan_run_01.txt /eos/user/.../scans/output_directory/scan_run_01_${mXd}.txt # Output from MadDM scan
cp EPS_1/Cards/param_card.dat /eos/user/.../params/output_directory/param_card_${mXd}.dat	# Param card for MadDM


