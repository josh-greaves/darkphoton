#include "NYStyle.h"

void output_eps() { 
  Prep();
  TCanvas *lC0 = new TCanvas("c1","c1",800,600);
  TFile *lFile = new TFile("testout.root");
  TTree *lTree = (TTree*) lFile->FindObjectAny("relic");
  
  //~ Set bin sizes manually
  TH2F  *lH2D   = new TH2F("HAHM_DP","HAHM_DP",201,-0.5,200.5,201,-0.5,200.5);  
  
  lTree->Draw("dm:med>>HAHM_DP","max(gq2,1e-6) ");  
  //~ lTree->Draw("dm:med>>HAHM_DP","max(max(gq2,1e-12) *(gq2<1),max(gq1,1e-12) *(gq1<1))");     // I think here I am undoing the bln flip. post processing to the max!
  
  lH2D->GetXaxis()->SetTitle("m_{med}(GeV)");
  lH2D->GetYaxis()->SetTitle("m_{dm}(GeV)");
  lH2D->GetZaxis()->SetTitle("eps min");
  //~ lH2D->GetZaxis()->SetRangeUser(5e-5,1);
  lH2D->GetZaxis()->SetRangeUser(0.001,10.);
  //lC0->SetLogx();
  //lC0->SetLogy();
  lC0->SetLogz();
  lC0->SetRightMargin(0.18);
  lC0->SetBottomMargin(0.18);
  lH2D->Draw("colz");

}

