#! /usr/bin/env python
import numpy as np
import csv
import ROOT as r
from optparse import OptionParser

parser = OptionParser()
parser.add_option('--dm'  ,action='store',type='float',dest='dm'    ,default=1,help='input file')
(options,args) = parser.parse_args()

# qg = float(sys.argv[2])

lFile = r.TFile("Output.root","RECREATE")
lTree = r.TTree("relic","relic")
p1 = np.zeros(1, dtype=float)
p2 = np.zeros(1, dtype=float)
p3 = np.zeros(1, dtype=float)
om = np.zeros(1, dtype=float)
lTree.Branch("med",p1,"p1/D")
lTree.Branch("dm" ,p2,"p2/D")
lTree.Branch("gq" ,p3,"p3/D")
lTree.Branch("om" ,om,"om/D")

with open('DMS_1/output/scan_run_01.txt') as csvfile:
        line = csv.reader(csvfile, delimiter='\t', quotechar='|')
        for row in line:
                print(row)
                if len(row) == 0: 
                        continue
                if row[0].split()[0] == '#':
                        continue
                # These values below may need adjusting - they correspond to the columns in scan_run_01.txt
                p1[0] = float(row[7])
                p2[0] = options.dm
                p3[0] = float(row[1])
                om[0] = float(row[8])
                print "test",p1,p2,p3,om
                lTree.Fill()

lFile.cd()
lTree.Write()
lFile.Close()
