#include "NYStyle.h"

void output_dms() { 
  Prep();
  TCanvas *lC0 = new TCanvas("c1","c1",800,600);
  
  TFile *lFile = new TFile("Output_proc_merged.root");
  TTree *lTree = (TTree*) lFile->FindObjectAny("relic");
  
  //~ set bin sizes manually
  TH2F  *lH2D   = new TH2F("DMsimp","DMsimp",201,-0.5,2000.5,1001,-0.5,1000.5);  
  
  lTree->Draw("dm:med>>DMsimp","max(gq2,1e-6)");
  
  lH2D->SetTitle("Vector - DMsimp");
  lH2D->GetXaxis()->SetTitle("m_{med}(GeV)");
  lH2D->GetYaxis()->SetTitle("m_{dm}(GeV)");
  lH2D->GetZaxis()->SetTitle("g_{q}min");
  //~ lH2D->GetZaxis()->SetRangeUser(5e-4,10);
  lH2D->GetZaxis()->SetRangeUser(0.001,10.);
  //lC0->SetLogx();
  //lC0->SetLogy();
  lC0->SetLogz();
  lC0->SetRightMargin(0.18);
  lC0->SetBottomMargin(0.18);
  lH2D->Draw();
  lH2D->Draw("colz");

}
