from ROOT import TCanvas, TPad, TFile, TPaveText, TGraphAsymmErrors, TMultiGraph
from ROOT import gBenchmark, gStyle, gROOT
from matplotlib.lines import Line2D
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np

# Format axes
def myticks(x,pos):
    return "$10^{:.0f}$".format(x)

   
## DMsimp values, expected  gq = 0.01, ptj=200
# Dark Matter masses (mDM)
def dms_exp():
    pId=0
    x = np.linspace(0,0,21)
    y = np.linspace(0,0,21)
    x[pId] = 1; y[pId] = 0.01286949678; pId +=1;
    x[pId] = 3; y[pId] = 0.01190089525; pId +=1;
    x[pId] = 5; y[pId] = 0.01148288275; pId +=1;
    x[pId] = 7; y[pId] = 0.0124222248; pId +=1;
    x[pId] = 10; y[pId] = 0.01264112081; pId +=1;
    x[pId] = 14; y[pId] = 0.01355619805; pId +=1;
    x[pId] = 17; y[pId] = 0.01336427007; pId +=1;
    x[pId] = 20; y[pId] = 0.0130273463; pId +=1;
    x[pId] = 24; y[pId] = 0.0127721362; pId +=1;
    x[pId] = 27; y[pId] = 0.01363046465; pId +=1;
    x[pId] = 30; y[pId] = 0.01281051965; pId +=1;
    x[pId] = 33; y[pId] = 0.01363046465; pId +=1;
    x[pId] = 40; y[pId] = 0.01512690894; pId +=1;
    x[pId] = 50; y[pId] = 0.01520526225; pId +=1;
    x[pId] = 70; y[pId] = 0.01591026256; pId +=1;
    x[pId] = 100; y[pId] = 0.01732558194; pId +=1;
    x[pId] = 200; y[pId] = 0.04259774712; pId +=1;
    x[pId] = 600; y[pId] = 0.4788569053; pId +=1;
    x[pId] = 800; y[pId] = 1.140307178; pId +=1;
    x[pId] = 1000; y[pId] = 2.150725378; pId +=1;
    x[pId] = 1200; y[pId] = 3.799332279; pId +=1;
    y/=np.sqrt(1.3)				# LO to NLO scaling k-factor
    return x,y



## DMsimp values, observed  gq = 0.01, ptj=200
# Dark Matter masses (mDM)
def dms_obs():
    pId=0
    x = np.linspace(0,0,21)
    y = np.linspace(0,0,21)
    x[pId] = 1; y[pId] = 0.02502542129; pId +=1;
    x[pId] = 3; y[pId] = 0.02487470186; pId +=1;
    x[pId] = 5; y[pId] = 0.0249914748; pId +=1;
    x[pId] = 7; y[pId] = 0.02538353696; pId +=1;
    x[pId] = 10; y[pId] = 0.0257763089; pId +=1;
    x[pId] = 14; y[pId] = 0.0260220736; pId +=1;
    x[pId] = 17; y[pId] = 0.02671504837; pId +=1;
    x[pId] = 20; y[pId] = 0.02660372746; pId +=1;
    x[pId] = 24; y[pId] = 0.02695368841; pId +=1;
    x[pId] = 27; y[pId] = 0.02758936741; pId +=1;
    x[pId] = 30; y[pId] = 0.02250735268; pId +=1;
    x[pId] = 33; y[pId] = 0.02843259307; pId +=1;
    x[pId] = 40; y[pId] = 0.02653579554; pId +=1;
    x[pId] = 50; y[pId] = 0.02696448587; pId +=1;
    x[pId] = 70; y[pId] = 0.02963353876; pId +=1;
    x[pId] = 200; y[pId] = 0.05917465992; pId +=1;
    x[pId] = 600; y[pId] = 1.213656492; pId +=1;
    x[pId] = 800; y[pId] = 1.483016124; pId +=1;
    x[pId] = 1000; y[pId] = 2.967273602; pId +=1;
    x[pId] = 1200; y[pId] = 9.460104467; pId +=1;
    y/=np.sqrt(1.3)
    return x,y


## HAHM model values, expected  eps = 0.01, ptj=200   
# Dark Matter masses (mDM)
def hahm_exp():
    pId=0
    x = np.linspace(0,0,22)
    y = np.linspace(0,0,22)
    x[pId] = 1; y[pId] = 0.06840759906; pId +=1;
    x[pId] = 3; y[pId] = 0.05504122447; pId +=1;
    x[pId] = 5; y[pId] = 0.06520241254; pId +=1;
    x[pId] = 7; y[pId] = 0.0648757068; pId +=1;
    x[pId] = 10; y[pId] = 0.0564536695; pId +=1;
    x[pId] = 14; y[pId] = 0.06617650819; pId +=1;
    x[pId] = 17; y[pId] = 0.05654570098; pId +=1;
    x[pId] = 20; y[pId] = 0.0481716917; pId +=1;
    x[pId] = 24; y[pId] = 0.03184966664; pId +=1;
    x[pId] = 27; y[pId] = 0.01782808397; pId +=1;
    x[pId] = 30; y[pId] = 0.001540138041; pId +=1;
    x[pId] = 33; y[pId] = 0.01080421466; pId +=1;
    x[pId] = 40; y[pId] = 0.03655238343; pId +=1;
    x[pId] = 50; y[pId] = 0.06232681517; pId +=1;
    x[pId] = 70; y[pId] = 0.07642855981; pId +=1;
    x[pId] = 100; y[pId] = 0.08898732472; pId +=1;
    x[pId] = 200; y[pId] = 0.1287263307; pId +=1;
    x[pId] = 400; y[pId] = 0.2728495308; pId +=1;
    x[pId] = 600; y[pId] = 0.4974856133; pId +=1;
    x[pId] = 800; y[pId] = 0.9498312941; pId +=1;
    x[pId] = 1000; y[pId] = 1.757976041; pId +=1;
    x[pId] = 1200; y[pId] = 3.109781043; pId +=1;
    return x,y




## HAHM model values, observed  eps = 0.01, ptj=200
# Dark Matter masses (mDM)
def hahm_obs():
    pId=0
    x = np.linspace(0,0,22)
    y = np.linspace(0,0,22)
    x[pId] = 1; y[pId] = 0.1156476963; pId +=1;
    x[pId] = 3; y[pId] = 0.09675631579; pId +=1;
    x[pId] = 5; y[pId] = 0.1260547549; pId +=1;
    x[pId] = 7; y[pId] = 0.1262452605; pId +=1;
    x[pId] = 10; y[pId] = 0.1054885799; pId +=1;
    x[pId] = 14; y[pId] = 0.1190522835; pId +=1;
    x[pId] = 17; y[pId] = 0.1095656964; pId +=1;
    x[pId] = 20; y[pId] = 0.09665289022; pId +=1;
    x[pId] = 24; y[pId] = 0.05703511654; pId +=1;
    x[pId] = 27; y[pId] = 0.0316169813; pId +=1;
    x[pId] = 30; y[pId] = 0.002669166991; pId +=1;
    x[pId] = 33; y[pId] = 0.0190391239; pId +=1;
    x[pId] = 40; y[pId] = 0.06594753947; pId +=1;
    x[pId] = 50; y[pId] = 0.1089194644; pId +=1;
    x[pId] = 70; y[pId] = 0.1328586016; pId +=1;
    x[pId] = 100; y[pId] = 0.149694075; pId +=1;
    x[pId] = 200; y[pId] = 0.2003822434; pId +=1;
    x[pId] = 400; y[pId] = 0.3727998329; pId +=1;
    x[pId] = 600; y[pId] = 0.6956651493; pId +=1;
    x[pId] = 800; y[pId] = 1.304851841; pId +=1;
    x[pId] = 1000; y[pId] = 2.42102134; pId +=1;
    x[pId] = 1200; y[pId] = 4.222502277; pId +=1;
    return x,y

## DMsimp HL-LHC  gq = 0.01, ptj=200
def dms_exp_HL():
    pId=0
    x = np.linspace(0,0,21)
    y = np.linspace(0,0,21)
    x[pId] = 1; y[pId] = 0.002780129052; pId +=1;
    x[pId] = 3; y[pId] = 0.002570887207; pId +=1;
    x[pId] = 5; y[pId] = 0.002480586186; pId +=1;
    x[pId] = 7; y[pId] = 0.00268350726; pId +=1;
    x[pId] = 10; y[pId] = 0.002730794203; pId +=1;
    x[pId] = 14; y[pId] = 0.002928473481; pId +=1;
    x[pId] = 17; y[pId] = 0.002887012298; pId +=1;
    x[pId] = 20; y[pId] = 0.002814228446; pId +=1;
    x[pId] = 24; y[pId] = 0.002759096763; pId +=1;
    x[pId] = 27; y[pId] = 0.0029445169; pId +=1;
    x[pId] = 30; y[pId] = 0.002767388535; pId +=1;
    x[pId] = 33; y[pId] = 0.003011991482; pId +=1;
    x[pId] = 40; y[pId] = 0.003267785814; pId +=1;
    x[pId] = 50; y[pId] = 0.003284712062; pId +=1;
    x[pId] = 70; y[pId] = 0.003437009536; pId +=1;
    x[pId] = 100; y[pId] = 0.003742753466; pId +=1;
    x[pId] = 200; y[pId] = 0.009202165114; pId +=1;
    x[pId] = 600; y[pId] = 0.1034449145; pId +=1;
    x[pId] = 800; y[pId] = 0.2463345047; pId +=1;
    x[pId] = 1000; y[pId] = 0.4646097829; pId +=1;
    x[pId] = 1200; y[pId] = 0.8207495775; pId +=1;
    y*=np.sqrt(1.3)     # Scale up to approximate NLO so that comparable with CMS
    return x,y


## HAHM HL-LHC values, expected  eps = 0.01, ptj=200   
# Dark Matter masses (mDM)
def hahm_exp_HL():
    pId=0
    x = np.linspace(0,0,21)
    y = np.linspace(0,0,21)
    x[pId] = 1; y[pId] = 0.01477773038; pId +=1;
    x[pId] = 3; y[pId] = 0.01189026345; pId +=1;
    x[pId] = 5; y[pId] = 0.01408533095; pId +=1;
    x[pId] = 7; y[pId] = 0.01401475445; pId +=1;
    x[pId] = 10; y[pId] = 0.01219538645; pId +=1;
    x[pId] = 14; y[pId] = 0.01429575966; pId +=1;
    x[pId] = 17; y[pId] = 0.01221526752; pId +=1;
    x[pId] = 20; y[pId] = 0.01040627476; pId +=1;
    x[pId] = 24; y[pId] = 0.006880314361; pId +=1;
    x[pId] = 27; y[pId] = 0.003851306311; pId +=1;
    x[pId] = 30; y[pId] = 0.0003327078429; pId +=1;
    x[pId] = 33; y[pId] = 0.002333977122; pId +=1;
    x[pId] = 40; y[pId] = 0.007896217297; pId +=1;
    x[pId] = 50; y[pId] = 0.01346413092; pId +=1;
    x[pId] = 70; y[pId] = 0.01651045594; pId +=1;
    x[pId] = 100; y[pId] = 0.01922345923; pId +=1;
    x[pId] = 200; y[pId] = 0.02780806569; pId +=1;
    x[pId] = 600; y[pId] = 0.1074691754; pId +=1;
    x[pId] = 800; y[pId] = 0.2051870108; pId +=1;
    x[pId] = 1000; y[pId] = 0.3797662292; pId +=1;
    x[pId] = 1200; y[pId] = 0.6717894857; pId +=1;
    return x,y



# Transform gq values (includes scale)
def transform(gq,gdm=1.0,iRatio=3.):
    out=(2/np.sqrt(1.-0.23))*(128./4./3.14)*gq*gq*np.power(1./iRatio,4.)*gdm*gdm/np.pi/4.
    return out

# Scale eps values
def scale(eps,gdm=1.0,iRatio=3.):
    out=eps*eps*np.power(1./iRatio,4.)*gdm*gdm/np.pi/4.
    return out


# load relic density (archived root file)
import uproot
file = uproot.open("relic_v6_V_Res_v2.root")
events = file['relic']
vals=events.arrays(['med','gq1'],'(abs(med-dm/0.3)/med < 0.002) & (gq1 != -5) & (gq1 != -1) & (med < 250) ',library="np")
med=vals['med'][vals['med'].argsort()]
gq=np.exp(vals['gq1'][vals['med'].argsort()])
X_rx=[] 
Y_ry = []
X_rx=np.append(med,X_rx)
Y_ry=np.append(gq,Y_ry)


# load DMsimp relic density (Vector model)
file = uproot.open("DMS_relic.root")
events = file['relic']
vals=events.arrays(['dm','gq2'],'(gq2 != -5) & (gq2 != -1) ',library="np")
dm=vals['dm'][vals['dm'].argsort()]
gq=vals['gq2'][vals['dm'].argsort()]
X_dms_rx = []
Y_dms_ry = []
X_dms_rx=np.append(dm,X_dms_rx)
Y_dms_ry=np.append(gq,Y_dms_ry)
Y_eps_dms_ry=transform(Y_dms_ry)


# load HAHM relic density (dark photon model)
file = uproot.open("HAHM_relic.root")
vals=events.arrays(['dm','gq2'], '(gq2 != -5) & (gq2 != -1) & (gq2 != 0)  ', library="np")
dm=vals['dm'][vals['dm'].argsort()]
eps=vals['gq2'][vals['dm'].argsort()]
X_hahm_rx = []
Y_hahm_ry = []
X_hahm_rx = np.append(dm,X_hahm_rx)
Y_hahm_ry = np.append(eps,Y_hahm_ry)
Y_eps_hahm_ry=scale(Y_hahm_ry)

# Connect ROOT histogram file, CMS monojet data cms_exo_20_004
f1 = TFile('HEPData.root')

d = gROOT.FindObject('Coupling limits on g_{q}, vector mediator')

alpha_dm = 0.1
scale_factor = (alpha_dm)*(4)*((np.e)**2)*(0.77663)/(3**4)   # Temporary scaling for CMS data

grObserved = d.Get('Graph1D_y1')
grMedExp = d.Get('Graph1D_y2')
grP1SD = d.Get('Graph1D_y3')
grP2SD = d.Get('Graph1D_y4')
grM1SD = d.Get('Graph1D_y5')
grM2SD = d.Get('Graph1D_y6')

x_arrays=[]
gr_arrays=[]
y_arrays=[]
y_arrays_scaled=[]

gr_arrays.append(grObserved)
gr_arrays.append(grMedExp)
gr_arrays.append(grP1SD)
gr_arrays.append(grP2SD)
gr_arrays.append(grM1SD)
gr_arrays.append(grM2SD)

largest_array = max(len(grObserved.GetX()), len(grMedExp.GetX()), \
           len(grP1SD.GetX()), len(grP2SD.GetX()), \
           len(grM1SD.GetX()), len(grM2SD.GetX()))

largest_x = max(max(grObserved.GetX()), max(grMedExp.GetX()), \
           max(grP1SD.GetX()), max(grP2SD.GetX()), \
           max(grM1SD.GetX()), max(grM2SD.GetX()))

yvals = []
for gr_array in gr_arrays:
    for y in gr_array.GetY():
        yvals.append(y)
maxY = max(yvals)

X_Observed=[max(grObserved.GetX())]*largest_array
X_MedExp=[max(grMedExp.GetX())]*largest_array
X_P1SD=[max(grP1SD.GetX())]*largest_array
X_P2SD=[max(grP2SD.GetX())]*largest_array
X_M1SD=[max(grM1SD.GetX())]*largest_array
X_M2SD=[max(grM2SD.GetX())]*largest_array

Y_Observed=[maxY]*largest_array
Y_MedExp=[maxY]*largest_array
Y_P1SD=[maxY]*largest_array
Y_P2SD=[maxY]*largest_array
Y_M1SD=[maxY]*largest_array
Y_M2SD=[maxY]*largest_array

Y_Observed_scaled=[(maxY**2)*scale_factor]*largest_array
Y_MedExp_scaled=[(maxY**2)*scale_factor]*largest_array
Y_P1SD_scaled=[(maxY**2)*scale_factor]*largest_array
Y_P2SD_scaled=[(maxY**2)*scale_factor]*largest_array
Y_M1SD_scaled=[(maxY**2)*scale_factor]*largest_array
Y_M2SD_scaled=[(maxY**2)*scale_factor]*largest_array

x_arrays.append(X_Observed)
x_arrays.append(X_MedExp)
x_arrays.append(X_P1SD)
x_arrays.append(X_P2SD)
x_arrays.append(X_M1SD)
x_arrays.append(X_M2SD)

y_arrays.append(Y_Observed)
y_arrays.append(Y_MedExp)
y_arrays.append(Y_P1SD)
y_arrays.append(Y_P2SD)
y_arrays.append(Y_M1SD)
y_arrays.append(Y_M2SD)
y_arrays.append(Y_ry)

y_arrays_scaled.append(Y_Observed_scaled)
y_arrays_scaled.append(Y_MedExp_scaled)
y_arrays_scaled.append(Y_P1SD_scaled)
y_arrays_scaled.append(Y_P2SD_scaled)
y_arrays_scaled.append(Y_M1SD_scaled)
y_arrays_scaled.append(Y_M2SD_scaled)

for g in range(0,len(gr_arrays)):
    for i in range(0, len(gr_arrays[g].GetX())):
        x_arrays[g][i]=gr_arrays[g].GetX()[i]
        y_arrays[g][i]=gr_arrays[g].GetY()[i]
        y_arrays_scaled[g][i]=((gr_arrays[g].GetY()[i])**2)*scale_factor

# Scaling by 1/3 to get MDM from CMS and relic data.
mDM_Obs =[]
for i in range(0,len(X_Observed)):
    mDM_Obs.append(X_Observed[i]/3)

mDM_MedExp =[]
for i in range(0,len(X_MedExp)):
    mDM_MedExp.append(X_MedExp[i]/3)

mDM_P1SD =[]
for i in range(0,len(X_P1SD)):
    mDM_P1SD.append(X_P1SD[i]/3)

mDM_P2SD =[]
for i in range(0,len(X_P2SD)):
    mDM_P2SD.append(X_P2SD[i]/3)

mDM_M1SD =[]
for i in range(0,len(X_M1SD)):
    mDM_M1SD.append(X_M1SD[i]/3)

mDM_M2SD =[]
for i in range(0,len(X_M2SD)):
    mDM_M2SD.append(X_M2SD[i]/3)

mDM_rx =[]
for i in range(0,len(X_rx)):
    mDM_rx.append(X_rx[i]/3)


# Load DMsimp values
X_mDM_dms_full, Y_gq_dms_full = dms_exp()
X_mDM_dms_obs, Y_gq_dms_obs = dms_obs()

# Truncate DMsimp up to the start of CMS exp data
X_mDM_dms = X_mDM_dms_full[0:12]
Y_gq_dms=Y_gq_dms_full[0:12]
Y_dms_HL=Y_gq_dms/(np.sqrt(3000/140))
Y_cms_HL = Y_MedExp/(np.sqrt(3000/140))

# Load HAHM values
X_mDM_hahm, Y_hahm_exp = hahm_exp()
X_mDM_hahm, Y_hahm_obs = hahm_obs()
X_mDM_hahm_HL, Y_hahm_exp_HL = hahm_exp_HL()

# scale model y values
Y_eps_dms=transform(Y_gq_dms)
Y_eps_dms_obs=transform(Y_gq_dms_obs)
Y_eps_dms_HL = transform(Y_dms_HL)
Y_eps_cms_HL = np.append(Y_eps_dms_HL, transform(Y_cms_HL))
X_cms_HL = np.append(X_mDM_dms, mDM_MedExp) 
Y_eps_hahm_exp = scale(Y_hahm_exp)
Y_eps_hahm_obs = scale(Y_hahm_obs)
Y_eps_hahm_exp_HL = scale(Y_hahm_exp_HL)
Y_eps_hahm_relic = scale(Y_hahm_ry)

# plot MMed rescaled by 1/3
fig, ax = plt.subplots(1,1, figsize=(8,6))

ax.plot(np.log10(mDM_Obs),np.log10(Y_Observed_scaled), 'ko-')
ax.plot(np.log10(mDM_MedExp),np.log10(Y_MedExp_scaled), 'ko--', markerfacecolor='green')
ax.plot(np.log10(mDM_P1SD),np.log10(Y_P1SD_scaled), color='green')
ax.plot(np.log10(mDM_P2SD),np.log10(Y_P2SD_scaled), color='yellow')
ax.plot(np.log10(mDM_M1SD),np.log10(Y_M1SD_scaled), color='green')
ax.plot(np.log10(mDM_M2SD),np.log10(Y_M2SD_scaled), color='yellow')

ax.set_yticks(np.arange(-12, 0, 1))
ax.set_ylim([-10, -1])
ax.set_xticks(np.arange(1, 4, 1))
ax.set_xlim([0.5, 3.5])

# custom tick marks
ax.xaxis.set_major_formatter(ticker.FuncFormatter(myticks))
ax.yaxis.set_major_formatter(ticker.FuncFormatter(myticks))

# # plot MMed scaled by 1/3
ax.fill_between(np.log10(mDM_M1SD), np.log10(Y_M1SD_scaled), np.log10(Y_P1SD_scaled), color='green')
ax.fill_between(np.log10(mDM_M2SD), np.log10(Y_M2SD_scaled), np.log10(Y_M1SD_scaled), color='yellow')
ax.fill_between(np.log10(mDM_P1SD), np.log10(Y_P1SD_scaled), np.log10(Y_P2SD_scaled), color='yellow')

# r denotes raw string literal, ignoring line breaks, to allow here for latex.
ax.set_ylabel(r'$ \epsilon^{2} \alpha (m_{DM}/m_{med})^{4}$')
ax.set_title('Upper limit on mixing parameter $\epsilon$')
ax.grid(linestyle='--')
ax.set_xlabel('$M_{DM}$ (GeV)')
ax.annotate('Vector mediator', xy=(0.05,0.9), xycoords='axes fraction', color='black')
ax.annotate('$g_x = 1.0$',  xy=(0.05,0.85), xycoords='axes fraction', color='black')
ax.annotate('$M_{DM} = M_{med}/3$',  xy=(0.05,0.8), xycoords='axes fraction', color='black')
ax.annotate('$alpha_{D}$ = %.2f' %alpha_dm, xy=(0.05,0.75), xycoords='axes fraction', color='black')

# Relic values
plt.plot(np.log10(X_dms_rx),np.log10(Y_eps_dms_ry),label='relic',c='b')   
# Remove the end diverging values from the plot for HAHM relic line 
plt.plot(np.log10(X_hahm_rx[0:len(X_hahm_rx)-57]),np.log10(Y_eps_hahm_ry[0:len(Y_eps_hahm_ry)-57]),linestyle='--',label='relic',c='b')

# Model values
plt.plot(np.log10(X_mDM_dms),np.log10(Y_eps_dms),label='DMsimp expected',c='r')
plt.plot(np.log10(X_cms_HL),np.log10(Y_eps_cms_HL),label='CMS HL-LHC',c='orange')
plt.plot(np.log10(X_mDM_hahm),np.log10(Y_eps_hahm_exp),label='HAHM expected',c='purple')
plt.plot(np.log10(X_mDM_hahm_HL),np.log10(Y_eps_hahm_exp_HL),label='HAHM exp HL-LHC',linestyle='--',c='orange')
plt.plot(np.log10(X_mDM_hahm),np.log10(Y_eps_hahm_obs),label='HAHM observed',c='grey')

# Legend
legend_elements = [ \
                Line2D([0], [0], color='black', marker = 'o', label='CMS observed'), \
                Line2D([0], [0], color='black', linestyle='--', marker = 'o', markerfacecolor='white', label='CMS expected'), \
                Line2D([0], [0], color='green', lw=8,  label='68% CL'), \
                Line2D([0], [0], color='yellow', lw=8,  label='95% CL'), \
                Line2D([0], [0], color='red',  label='DMsimp expected'), \
                Line2D([0], [0], color='blue', linestyle='--', label='Relic DMsimp'), \
                Line2D([0], [0], color='blue', linestyle='--', label='Relic HAHM'), \
                Line2D([0], [0], color='purple', label='HAHM expected'), \
                Line2D([0], [0], color='grey', label='HAHM observed'), \
                Line2D([0], [0], color='orange', linestyle='--', label='HAHM exp HL-LHC'), \
                Line2D([0], [0], color='orange', label='DMsimp exp HL-LHC') \
                ]

plt.legend(handles=legend_elements, loc = 'lower right').get_frame().set_linewidth(0.0)
fig.tight_layout(pad=3.0)
plt.show()

# plt.savefig('figoutlog', dpi = 300)
