#! /usr/bin/env python
import os,sys


# ~ tmp_array=[1,2]
# ~ for j in range(4,2004,4):
    # ~ tmp_array.append(j)

# ~ MXd_array=[]
# ~ for i in range(1,2001,1):
    # ~ #if i not in(tmp_array):
    # ~ MXd_array.append(i)
    
MXd_array=[1,3,5,7,10,14,17,20,24,27,30,33,40,50,70,100,200,400,600,800,1000,1200]

MXd_array=[1,5,10,14,24,27,30,40,50,70,600,800,1000,1200]
    

# ~ MXd_array=[70]

# Submit one job to condor for each Dark Matter mass mXd. 
for MXd in MXd_array:
	MY1 = 3*MXd
	cmd ="./run_mg5_HAHM_tmp.sh %s %s & wait;"%(str(MXd),str(MY1))
	# ~ cmd ="./submit_condor_mg5.sh run_mg5_HAHM.sh %s %s"%(str(MXd),str(MY1))
	print(cmd)
	os.system(cmd)
	
