#!/bin/bash

mXd=$1
mZd=$2
#mXd=9
#mdm1=$mdm
#mdm1=$(( 0.01*mdm ))

# rm -rf MG5_aMC_v2_9_4/

# Point this at the zipped up MG5 configuration, for unzipping to 'condor space'. If you want to run locally (no condor) then comment this out.
tar xzvf /eos/user/j/jgreaves/MadDM/mg5.tgz

cd MG5_aMC_v2_9_4/ 

rm mg5_input.txt

echo "import model DMsimp_s_spin1 " > mg5_input.txt
echo "generate p p > xd xd~ j " >> mg5_input.txt
echo "output DMS_$mXd " >> mg5_input.txt
echo "launch " >> mg5_input.txt
echo "shower=Pythia8 " >> mg5_input.txt
echo "analysis=MadAnalysis5 " >> mg5_input.txt
echo "set gVd11 0.01" >> mg5_input.txt
echo "set gVd22 0.01" >> mg5_input.txt
echo "set gVd33 0.01" >> mg5_input.txt
echo "set gVu11 0.01" >> mg5_input.txt
echo "set gVu22 0.01" >> mg5_input.txt
echo "set gVu33 0.01" >> mg5_input.txt
echo "set my1 $mZd" >> mg5_input.txt
echo "set mxd $mXd " >> mg5_input.txt
echo "set wy1 auto" >> mg5_input.txt
echo "set ebeam1 6500 " >> mg5_input.txt
echo "set ebeam2 6500 " >> mg5_input.txt
echo "set nevents 10000 " >> mg5_input.txt
echo "set ptj 200 " >> mg5_input.txt 

# Launch MadGraph
python bin/mg5_aMC mg5_input.txt




# Collect output files

#~ cat /tmp/jgreaves/DMS_$mXd/Cards/param_card.dat
#~ cat /tmp/jgreaves/DMS_$mXd/Cards/run_card.dat
#~ mkdir /eos/user/j/jgreaves/mg_DMS_output_$(date +%j)
#~ cp -r /tmp/jgreaves/DMS_$mXd /eos/user/j/jgreaves/mg_DMS_output_$(date +%j)

cat DMS_$mXd/Cards/param_card.dat
cat DMS_$mXd/Cards/run_card.dat
mkdir /eos/user/j/jgreaves/mg_DMS_output_$(date +%j)
cp -r DMS_$mXd /eos/user/j/jgreaves/mg_DMS_output_$(date +%j)

