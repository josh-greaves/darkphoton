#!/bin/bash

mXd=$1
mZd=$(( 3*$mXd )) # $2
#~ eps=$3
#mXd=9
#mdm1=$mdm
#mdm1=$(( 0.01*mdm ))

# rm -rf MG5_aMC_v2_9_4/

# Point this at the zipped up MG5 configuration, for unzipping to 'condor space'. If you want to run locally (no condor) then comment this out.
tar xzvf /eos/user/j/jgreaves/MadDM/mg5.tgz

cd MG5_aMC_v2_9_4/ 

rm mg5_input.txt


echo "import model HAHM_variableMW_v3_UFO " > mg5_input.txt
echo "generate p p > xd xd~ j " >> mg5_input.txt
echo "output HAHM_$mXd " >> mg5_input.txt
echo "launch " >> mg5_input.txt
echo "shower=Pythia8 " >> mg5_input.txt
echo "analysis=MadAnalysis5 " >> mg5_input.txt
echo "set mZDinput $mZd" >> mg5_input.txt
echo "set mxd $mXd " >> mg5_input.txt
echo "set epsilon 0.01 " >> mg5_input.txt
echo "set wzp auto" >> mg5_input.txt
echo "set ebeam1 6500 " >> mg5_input.txt
echo "set ebeam2 6500 " >> mg5_input.txt
echo "set nevents 10000 " >> mg5_input.txt
echo "set ptj 200 " >> mg5_input.txt 


# Run MadGraph
python bin/mg5_aMC mg5_input.txt



# Sort output files - copy to desired /eos/ location. 

#~ cat /tmp/jgreaves/HAHM_$mXd/Cards/param_card.dat
#~ cat /tmp/jgreaves/HAHM_$mXd/Cards/run_card.dat
#~ mkdir /eos/user/j/jgreaves/mg_HAHM_output_$(date +%D)
#~ cp -r /tmp/jgreaves/HAHM_$mXd /eos/user/j/jgreaves/mg_HAHM_output_%s

cat HAHM_$mXd/Cards/param_card.dat
cat HAHM_$mXd/Cards/run_card.dat
mkdir /eos/user/j/jgreaves/mg_HAHM_output_$(date +%j)
cp -r HAHM_$mXd /eos/user/j/jgreaves/mg_HAHM_output_$(date +%j)

