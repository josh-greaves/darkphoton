#!/bin/bash

arg=$2
exe=$1
#args=`echo "${@:3}"`

home=`pwd`

echo  "submitting jobs using "$exe" with arg:"$arg
echo "executable              = "$exe > tmp.sub
echo "arguments               = "$arg >> tmp.sub
echo "output                  = MadDM/relicroot/launch_relic/condor/output/mg.\$(ClusterId).\$(ProcId).out" >> tmp.sub
echo "error                   = MadDM/relicroot/launch_relic/condor/error/mg.\$(ClusterId).\$(ProcId).err"  >> tmp.sub
echo "log                     = MadDM/relicroot/launch_relic/condor/log/mg.\$(ClusterId).\$(ProcId).log"                >> tmp.sub
echo "+JobFlavour = \"espresso\"  " >> tmp.sub     # workday   # microcentury   # espresso  # longlunch
#~ echo "+MaxRuntime = 300" >> tmp.sub   # in seconds
echo "queue "    >> tmp.sub   # $N 
condor_submit tmp.sub

# ./run.sh 7
